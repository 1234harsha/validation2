import React, { useState, Fragment, useEffect } from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const AddSchedule = () => {
    const [Schedid, setId] = useState("");
    const [Clsid, setCid] = useState("");
    const [SessionTime, setSession] = useState("");
    const [Teacid, setTeacId] = useState("");
    const [Subjid, setSubId] = useState("");
    const [errors, setErrors] = useState({});
    const [validTeacId, setValidTeacId] = useState(false);
    const [validSubjId, setValidSubjId] = useState(false);
    const [scheduleIdExists, setScheduleIdExists] = useState(false);

    useEffect(() => {
        checkExistingSchedule();
    }, [Schedid]);

    useEffect(() => {
        checkTeacId();
    }, [Teacid]);

    useEffect(() => {
        checkSubjId();
    }, [Subjid]);

    const checkExistingSchedule = () => {
        if (Schedid) {
            axios.get(`http://localhost:5206/api/ScheduleClass/CheckSchedule/${Schedid}`)
                .then((response) => {
                    const exists = response.data.exists;
                    setScheduleIdExists(exists);
                })
                .catch((error) => console.log(error));
        }
    };

    const checkTeacId = () => {
        if (Teacid) {
            axios.get(`http://localhost:5206/api/Teacher/CheckTeacId/${Teacid}`)
                .then((response) => {
                    setValidTeacId(response.data.exists);
                })
                .catch((error) => console.log(error));
        }
    };

    const checkSubjId = () => {
        if (Subjid) {
            axios.get(`http://localhost:5206/api/Subject/CheckSubjId/${Subjid}`)
                .then((response) => {
                    setValidSubjId(response.data.exists);
                })
                .catch((error) => console.log(error));
        }
    };

    const validateInputs = () => {
        const errors = {};
        if (!Schedid) errors.scheduleId = "Schedule Id is required";
        else if (scheduleIdExists) errors.scheduleId = "Schedule Id already exists";
        if (!Clsid) errors.classId = "Class Id is required";
        if (!validTeacId) errors.teacId = "Teacher Id is not valid";
        if (!validSubjId) errors.subjId = "Subject Id is not valid";
        if (!SessionTime) errors.sessionTime = "Session Time is required";

        setErrors(errors);
        return Object.keys(errors).length === 0;
    };

    const Add = () => {
        if (validateInputs()) {
            let schedule = {
                scheduleId: Schedid,
                classId: Clsid,
                sessionTime: SessionTime,
                teacId: Teacid,
                subjId: Subjid,
            };
            axios
                .post("http://localhost:5206/api/ScheduleClass/AddSchedule", schedule)
                .then((response) => {
                    console.log(response.data);
                })
                .catch((error) => console.log(error));
        } else {
            toast.error("Please fill in all required fields correctly.");
        }
    };

    const handleScheduleIdChange = (e) => {
        const inputValue = e.target.value;
        setId(inputValue);
        setErrors(prevErrors => ({ ...prevErrors, scheduleId: '' }));
    };

    const handleClassIdChange = (e) => {
        const inputValue = e.target.value;
        setCid(inputValue);
        setErrors(prevErrors => ({ ...prevErrors, classId: '' }));
    };

    const handleSessionTimeChange = (e) => {
        const inputValue = e.target.value;
        setSession(inputValue);
        setErrors(prevErrors => ({ ...prevErrors, sessionTime: '' }));
    };

    const handleTeacherIdChange = (e) => {
        const inputValue = e.target.value;
        setTeacId(inputValue);
        setErrors(prevErrors => ({ ...prevErrors, teacId: '' }));
    };

    const handleSubjectIdChange = (e) => {
        const inputValue = e.target.value;
        setSubId(inputValue);
        setErrors(prevErrors => ({ ...prevErrors, subjId: '' }));
    };

    return (
        <Fragment>
            <ToastContainer />
            <Container>
                <h1>Schedule Class</h1>
                <br />
                <Row>
                    <Col>
                        <input type="text" className='form-control form-control-sm' placeholder='Enter Schedule Id '
                            value={Schedid} onChange={handleScheduleIdChange} />
                        {errors.scheduleId && <span className="text-danger">{errors.scheduleId}</span>}
                    </Col>
                </Row>
                <Row className='pt-2'>
                    <Col>
                        <input type="text" className='form-control form-control-sm' placeholder='Enter Class Id '
                            value={Clsid} onChange={handleClassIdChange} />
                        {errors.classId && <span className="text-danger">{errors.classId}</span>}
                    </Col>
                    <Col>
                        <input type="text" className='form-control form-control-sm' placeholder='Enter Session Time '
                            value={SessionTime} onChange={handleSessionTimeChange} />
                        {errors.sessionTime && <span className="text-danger">{errors.sessionTime}</span>}
                    </Col>
                </Row>
                <Row className='pt-2'>
                    <Col>
                        <input type="text" className='form-control form-control-sm' placeholder='Enter Teacher Id'
                            value={Teacid} onChange={handleTeacherIdChange} />
                        {errors.teacId && <span className="text-danger">{errors.teacId}</span>}
                    </Col>
                    <Col>
                        <input type="text" className='form-control form-control-sm' placeholder='Enter Subject Id'
                            value={Subjid} onChange={handleSubjectIdChange} />
                        {errors.subjId && <span className="text-danger">{errors.subjId}</span>}
                    </Col>
                </Row>
                <Row className='pt-2'>
                    <Col>
                        <button className='btn btn-primary ' onClick={() => Add()}>Add Schedule</button>
                    </Col>
                </Row>
            </Container>
        </Fragment>
    );
};

export default AddSchedule;
