import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"

  const GetSchedule1=()=>{
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
      //Edit
  const[UScheId,setUScheId]=useState("")
  const[UClsId,setUClsId]=useState("")
  const[USessionTime,setUSession]=useState("")
  const[UTeachId,setUTeachId]=useState("")
  const[USubId,setUSubId]=useState("")
  
  const [schedule,GetSchedules]=useState([]);

    useEffect(()=>{
        axios
            .get("http://localhost:5206/api/ScheduleClass/GetAll")
            .then((response)=>{
                console.log(response.data);//return dta send by json
                GetSchedules(response.data);//add response data to student state
            })
            .catch((error)=>{
                console.log(error);
            });
    },[schedule]);

    const [data,setdata] = useState([])

    const handleEdit =(scheduleId)=>{
        handleShow();
        axios.get(`http://localhost:5206/api/ScheduleClass/GetScheduleById/${scheduleId}`)
        .then((result)=>{
        })
        .catch((error)=>{
         toast.error(error)
        })
     }
 
    const handleUpdate = (e)=>{
        e.preventDefault();
        console.log("check");
        const url ='http://localhost:5206/api/ScheduleClass/Update'
        const data = {
            scheduleId: UScheId,
            classId: UClsId,
            sessionTime: USessionTime,
            teacId: UTeachId,
            subjId: USubId
       }
       console.log(data);
       
       axios.put(url,data)
       .then((result)=>{
         console.log("Entered into edit api");
         handleClose()
         console.log(result.data);
         toast.success("Schedules has been updated")
       })
       .catch((error)=>{
         console.log(error)
       })
       }
    
    return(
       <div>
        <div className="container">
            <h1>Class Schedule</h1>
            <br/><br/>
            <table className="table table-striped">
                <thead>
                    <tr>
                        {/* <th>TeacherID</th> */}
                        <th>Schedule Id</th>
                        <th>Session Time</th>
                        <th>Class Name</th>
                        {/* <th>phone Number</th> */}
                        <th>Teacher Name</th>
                        <th>Subject Name</th>
                    </tr>
                </thead>
                <tbody>
                {schedule.length > 0 && (
          schedule.map((schedule)=>{
            return(
              <tr>
                <td>{schedule.scheduleId}</td>
                <td>{schedule.sessionTime}</td>
                <td>{schedule.className}</td>
                <td>{schedule.teachName}</td>
                <td>{schedule.subName}</td>
                
                <button className='btn btn-warning' onClick={handleShow} style={{float:"left",padding:"13px"}}>Update</button> &nbsp;
              </tr>
            )
          })
        )}
                </tbody>
            </table>
        </div>
     
<Fragment>
 <ToastContainer/>
 <Container>

<Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modify /Update Schedule</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Row>
        <Col>
        <input type="text" className='form-control' placeholder='Class ID'
         onChange={(e)=> setUClsId(e.target.value)} />
        </Col>
        </Row>
        <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='Schedule ID'
         onChange={(e)=> setUScheId(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Session Time'
        onChange={(e)=> setUSession(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Subject ID'
         onChange={(e)=> setUSubId(e.target.value)} />
        </Col>
      </Row>
      <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='Teacher ID'
        onChange={(e)=> setUTeachId(e.target.value)} />
        </Col>
                    
      </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleUpdate}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
</Container>
</Fragment> 

</div>

    )
}
export default GetSchedule1;
