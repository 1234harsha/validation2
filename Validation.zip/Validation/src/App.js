import logo from './logo.svg';
import './App.css';
import AddSchedule from './AddSchedule';
import GetSchedule1 from './Update,View';



function App() {
  return (
    <div className="App">
     {/* <CId/> */}
     {/* <AddSchedule1/> */}
     <AddSchedule/>
     {/* <GetSchedule1/> */}
     {/* <TId/> */}
     {/* <GetSchedule1/> */}
    </div>
  );
}

export default App;
